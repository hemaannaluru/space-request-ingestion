package com.keylent.utils;

import java.time.LocalDateTime;

public final class TimeBuckets {

	public static LocalDateTime currentMinuteStart() {
		LocalDateTime now = LocalDateTime.now();
		return now.withSecond(0).withNano(0);
	}
}
