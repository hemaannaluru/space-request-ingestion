package com.keylent.controller;

import com.keylent.service.IngestService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/space")
public class AcceptController {

    private  IngestService ingestService;

    public AcceptController(IngestService ingestService) {
        this.ingestService = ingestService;
    }

    @GetMapping("/accept")
    public ResponseEntity<String> accept(@RequestParam("id") String id) {
        try {
            ingestService.accept(id);
            return ResponseEntity.ok("ok");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body("failed");
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("failed");
        }
    }
}
