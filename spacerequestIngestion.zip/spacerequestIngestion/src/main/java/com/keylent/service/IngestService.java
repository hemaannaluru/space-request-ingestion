package com.keylent.service;

import com.keylent.repo.MinuteEventRepository;
import com.keylent.utils.TimeBuckets;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

//Ingestion logic
@Service
public class IngestService {

    private final MinuteEventRepository minuteEventRepository;

    public IngestService(MinuteEventRepository minuteEventRepository) {
        this.minuteEventRepository = minuteEventRepository;
    }

    public void accept(String id) {
        validate(id);

        LocalDateTime minuteStart = TimeBuckets.currentMinuteStart();
        minuteEventRepository.recordSeen(minuteStart, id.trim());
    }

    private void validate(String id) {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("id must not be empty");
        }
    }
}
