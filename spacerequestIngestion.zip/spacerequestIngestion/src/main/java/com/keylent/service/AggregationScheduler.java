package com.keylent.service;

import com.keylent.repo.MinuteEventRepository;
import com.keylent.repo.MinuteStatsRepository;
import com.keylent.utils.TimeBuckets;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

//Runs once per minute to aggregate unique IDs.

@Service
public class AggregationScheduler {
    
	@Autowired
    private MinuteEventRepository minuteEventRepository;
	private  MinuteStatsRepository minuteStatsRepository;

   
    @Scheduled(cron = "5 * * * * *")
    public void aggregatePreviousMinute() {

        LocalDateTime currentMinute = TimeBuckets.currentMinuteStart();
        LocalDateTime previousMinute = currentMinute.minusMinutes(1);

        long uniqueCount = minuteEventRepository.countForMinute(previousMinute);

        System.out.println(previousMinute + " -> " + uniqueCount + " unique ids");

        minuteStatsRepository.upsert(previousMinute, uniqueCount);
    }
}

