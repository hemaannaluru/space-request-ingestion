package com.keylent.repo;

import java.time.LocalDateTime;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
//Responsible for Inserting records into DB and Counting Unique ID's  
@Repository
public class MinuteEventRepository {

	private JdbcTemplate jdbcTemplate;

	public MinuteEventRepository(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void recordSeen(LocalDateTime minuteStart, String id) {
		jdbcTemplate.update("INSERT IGNORE INTO minute_seen (minute_start, request_id) VALUES (?, ?)", minuteStart, id);
	}

	public long countForMinute(LocalDateTime minuteStart) {
		Long count = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM minute_seen WHERE minute_start = ?", Long.class,
				minuteStart);
		return count == null ? 0L : count;
	}
}
