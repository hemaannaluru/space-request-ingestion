package com.keylent.repo;


import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;


@Repository
public class MinuteStatsRepository {

    private  JdbcTemplate jdbcTemplate;

    public MinuteStatsRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public void upsert(LocalDateTime minuteStart, long uniqueCount) {
        jdbcTemplate.update(
            "INSERT INTO minute_stats (minute_start, unique_id_count) VALUES (?, ?) " +
            "ON DUPLICATE KEY UPDATE unique_id_count = VALUES(unique_id_count)",
            minuteStart,
            uniqueCount
        );
    }
}

